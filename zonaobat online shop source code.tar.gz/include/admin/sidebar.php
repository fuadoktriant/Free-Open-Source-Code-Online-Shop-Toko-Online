<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Panel Kontrol</h2>				 
    	                   <div class="list-group">
                               <a href="admin.php" class="list-group-item">Produk <span class="products-admin-badge pull-right text-info">0</span></a>   
                               <a href="order.php" class="list-group-item">Pesanan <span class="order-admin-badge pull-right text-danger">0</span></a> 
                               <a href="admincategory.php" class="list-group-item">Kategori <span class="category-admin-badge pull-right text-warning">0</span></a>                                                                                                                           
                            </div>
                            <div class="list-group">
                               <a href="logout.php" class="list-group-item active">Keluar</a>
                            </div>
                        </div>
                        </div>