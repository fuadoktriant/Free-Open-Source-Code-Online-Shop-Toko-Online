<?php
$mysql_hostname = "localhost";
$mysql_user = "k6239365_4dm1n";
$mysql_password = "harussukses28";
$mysql_database = "k6239365_dbzona_obat";
$prefix = "";
$bd = mysql_connect($mysql_hostname, $mysql_user, $mysql_password) or die("Could not connect database");
mysql_select_db($mysql_database, $bd) or die("Could not select database");
?>
