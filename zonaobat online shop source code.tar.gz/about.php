<?php include('include/home/header.php'); ?>
	
	<section id="form"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h2>Tentang Kami</h2>
						<address>
	    						<p>PT. Zona Obat Sejahtera</p>
								<p>Jl. Daan Mogot</p>
								<p>+62 838 7933 8666</p>
								<p>Fax:</p>
								<p>admin@zonaobat.com</p>
	    				</address>
					</div><!--/login form-->
				</div>
			</div>
		</div>
	</section><!--/form-->
	
	
<?php include('include/home/footer.php'); ?>