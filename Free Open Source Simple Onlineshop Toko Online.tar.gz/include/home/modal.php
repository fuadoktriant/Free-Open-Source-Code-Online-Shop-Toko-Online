<!-- Modal -->
<div class="modal fade" id="checkout_modal" role="dialog">
    <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Tutup</span></button>
        <h4 class="modal-title" id="myModalLabel"><i class="fa fa-shopping-cart text-success fa-lg"></i> Pembayaran <small class='text-primary'>Informasi Tagihan</small></h4>
      </div>
      <div class="modal-body">
        <form action="cart/data.php?q=checkout" method="POST">
            <div class="form-group">
                <label>Nama Depan</label>
                <input type="text" name="fname" class="form-control" placeholder="Contoh : Sukimin" required>
            </div>
            <div class="form-group">
                <label>Nama Belakang</label>
                <input type="text" name="lname" class="form-control" placeholder="Contoh : Parjo" required>
            </div>
            <div class="form-group">
                <label>No. Handphone</label>
                <input type="text" name="contact" class="form-control" placeholder="(Contoh : 0838 7933 8666)" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" placeholder="(Contoh : anda@domainanda.com)" class="form-control">
            </div>
            <div class="form-group">
                <label>Alamat Lengkap</label>
                <input type="text" name="address" class="form-control" placeholder="(Contoh : Jl. Daan Mogot Kel. Sukamandi Kec. Engga Bersih Tangerang Banten)" required>
            </div>
            <div class="alert alert-info">
                Metode Pembayaran: <strong>Bayar di Tempat</strong>
            </div>
            <div class="alert alert-warning">
                *** Mohon tunggu telepon/email dari kami, Terima Kasih ***
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
        <button type="submit" class="btn btn-success">Konfirmasi</button>
          </form>
      </div>
    </div>
  </div>
</div>